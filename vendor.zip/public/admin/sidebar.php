<!-- ===== SIDEBAR ADMIN ===== -->
<aside class="sidebar" id="sidebar">
  <h5><i class="fas fa-user-shield"></i> Admin UMKM</h5>

  <a href="dashboard.php" class="active">
    <i class="fas fa-chart-line"></i> Dashboard
  </a>

   <a href="admin.php">
    <i class="fas fa-users"></i> Manajeman Admin
  </a>

  <a href="umkm.php">
    <i class="fas fa-file-alt"></i> Data UMKM
  </a>

  <!-- VERIFIKASI = FILTER LIST -->
  <a href="umkm.php?filter=verifikasi">
    <i class="fas fa-check-circle"></i> Verifikasi
  </a>

  <a href="warga.php">
    <i class="fas fa-users"></i> Data Warga
  </a>

  <a href="pengaturan.php">
    <i class="fas fa-cog"></i> Pengaturan
  </a>

  <a href="../../controlls/logout.php">
    <i class="fas fa-sign-out-alt"></i> Logout
  </a>
</aside>
