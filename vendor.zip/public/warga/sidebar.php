<!-- ================= SIDEBAR ================= -->
<aside class="sidebar" id="sidebar">
  <h5><i class="fas fa-store"></i> Warga UMKM</h5>

  <a href="dashboard.php" class="active">
    <i class="fas fa-home"></i> Dashboard
  </a>

  <a href="ajukan_umkm.php">
    <i class="fas fa-file-alt"></i> Ajukan UMKM
  </a>

  <a href="status_umkm.php">
    <i class="fas fa-search"></i> Status UMKM
  </a>

  <a href="riwayat.php">
    <i class="fas fa-history"></i> Riwayat
  </a>

  <a href="../../controlls/logout.php">
    <i class="fas fa-sign-out-alt"></i> Logout
  </a>
</aside>
